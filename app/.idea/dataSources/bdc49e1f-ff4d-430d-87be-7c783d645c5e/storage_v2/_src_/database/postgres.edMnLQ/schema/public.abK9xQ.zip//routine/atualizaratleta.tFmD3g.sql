create function atualizaratleta(pestado boolean, pnome character varying, pmorada character varying, plocalidade character varying, pcodpostal character varying, pcontacto character varying, pemail character varying, pdatanasc date, pnumerocivil character varying, pnumerofiscal character varying, pnacionalidade character varying, pgrsangue character varying, pdoencasprobl character varying, phabilicao character varying, pfoto character varying, pposicao character varying, pnomecamisola character varying, pnumerocamisola character varying, ptamanhocamisola character varying, pnsocio character varying, pnlicenca character varying, pidfuncionario integer, piddocumentacao integer) returns void
    language plpgsql
as
$$
BEGIN
	update atleta 
	set estado = Pestado ,nome = Pnome, morada = Pmorada ,localidade = Plocalidade,codpostal = Pcodpostal,contacto = Pcontacto,email = Pemail,datanasc = PdataNasc,numerocivil = Pnumerocivil,numerofiscal = PnumeroFiscal,nacionalidade = Pnacionalidade,grsangue = Pgrsangue,doencasprobl = Pdoencasprobl,habilitacacao = Phabilicao,foto = Pfoto ,posicao = Pposicao,nomecamisola = Pnomecamisola ,numerocamisola = Pnumerocamisola,tamanhocamisola = Ptamanhocamisola,nsocio = Pnsocio,nlicenca = Pnlicenca,idfuncionario = Pidfuncionario,iddocumentacao = PidDocumentacao 
	where atleta.numerocivil = Pnumerocivil;
END;
$$;

alter function atualizaratleta(boolean, varchar, varchar, varchar, varchar, varchar, varchar, date, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, varchar, integer, integer) owner to grupo3_cde;

