create function st_approxhistogram(rastertable text, rastercolumn text, nband integer, sample_percent double precision, bins integer, "right" boolean, OUT min double precision, OUT max double precision, OUT count bigint, OUT percent double precision) returns SETOF record
    stable
    strict
    language sql
as
$$
SELECT public._ST_histogram($1, $2, $3, TRUE, $4, $5, NULL, $6)
$$;

alter function st_approxhistogram(text, text, integer, double precision, integer, boolean, out double precision, out double precision, out bigint, out double precision) owner to grupo1_ptas_2019;

