create function dropgeometrytable(schema_name character varying, table_name character varying) returns text
    strict
    language sql
as
$$
SELECT public.DropGeometryTable('',$1,$2)
$$;

comment on function dropgeometrytable(varchar, varchar) is 'args: schema_name, table_name - Drops a table and all its references in geometry_columns.';

alter function dropgeometrytable(varchar, varchar) owner to grupo1_ptas_2019;

