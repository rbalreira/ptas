create function st_curvetoline(geometry, integer) returns geometry
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT ST_CurveToLine($1, $2::float8, 0, 0)
$$;

comment on function st_curvetoline(geometry, integer) is 'args: curveGeom, segments_per_qtr_circle - Converts a CIRCULARSTRING/CURVEPOLYGON to a LINESTRING/POLYGON';

alter function st_curvetoline(geometry, integer) owner to grupo1_ptas_2019;

