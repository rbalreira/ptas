create view protocolos_equipas(geom, nome, contacto, morada, cod_postal, municipio, transporte, modalidade, escalao,
                               genero) as
SELECT st_asgeojson(st_transform(st_setsrid(r.geom, 3857), 4326)) AS geom,
       r.nome,
       r.contacto,
       r.morada,
       r.cod_postal,
       r.municipio,
       CASE
           WHEN (r.transporte = true) THEN 'Sim'::text
           ELSE 'Não'::text
           END                                                    AS transporte,
       m.nome                                                     AS modalidade,
       e.escalao,
       CASE
           WHEN (e.genero = 'm'::bpchar) THEN 'masculino'::text
           WHEN (e.genero = 'f'::bpchar) THEN 'feminino'::text
           ELSE ' '::text
           END                                                    AS genero
FROM (((representacao r
    LEFT JOIN protocolo p ON ((p.representacaoid = r.id)))
    LEFT JOIN equipa e ON (((e.id = p.equipaid) OR (e.representacao = r.id))))
         LEFT JOIN modalidade m ON ((m.id = e.modalidade)));

alter table protocolos_equipas
    owner to grupo1_ptas_2019;

