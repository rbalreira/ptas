create view pavilhoes_modalidades(pavilhao, nome) as
SELECT e.nome AS pavilhao,
       m.nome
FROM ((modalidade m
    JOIN modalidade_equipamentos me ON ((me.modalidadeid = m.id)))
         JOIN equipamentos_desportivos e ON ((e.id = me.equipamentosid)));

alter table pavilhoes_modalidades
    owner to grupo1_ptas_2019;

