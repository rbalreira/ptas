create function st_worldtorastercoord(rast raster, pt geometry, OUT columnx integer, OUT rowy integer) returns record
    immutable
    strict
    parallel safe
    language plpgsql
as
$$
DECLARE
		rx integer;
		ry integer;
	BEGIN
		IF public.ST_geometrytype(pt) != 'ST_Point' THEN
			RAISE EXCEPTION 'Attempting to compute raster coordinate with a non-point geometry';
		END IF;
		IF public.ST_SRID(rast) != public.ST_SRID(pt) THEN
			RAISE EXCEPTION 'Raster and geometry do not have the same SRID';
		END IF;

		SELECT rc.columnx AS x, rc.rowy AS y INTO columnx, rowy FROM public._ST_worldtorastercoord($1, public.ST_x(pt), public.ST_y(pt)) AS rc;
		RETURN;
	END;

$$;

comment on function st_worldtorastercoord(raster, geometry, out integer, out integer) is 'args: rast, pt - Returns the upper left corner as column and row given geometric X and Y (longitude and latitude) or a point geometry expressed in the spatial reference coordinate system of the raster.';

alter function st_worldtorastercoord(raster, geometry, out integer, out integer) owner to grupo1_ptas_2019;

