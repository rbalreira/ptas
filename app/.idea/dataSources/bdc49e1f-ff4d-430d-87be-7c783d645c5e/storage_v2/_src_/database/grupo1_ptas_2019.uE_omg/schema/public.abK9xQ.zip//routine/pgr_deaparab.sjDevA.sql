create function pgr_deaparab(tbl character varying, x1 double precision, y1 double precision, x2 double precision, y2 double precision, OUT seq integer, OUT gid integer, OUT name text, OUT heading double precision, OUT cost double precision, OUT geom geometry) returns SETOF record
    strict
    language plpgsql
as
$$
DECLARE
        sql     text;
        rec     record;
        source	integer;
        target	integer;
        point	integer;
        
BEGIN
	-- Find nearest node
	EXECUTE 'SELECT id::integer FROM rede_viaria_bv_vertex 
			ORDER BY geom_vertex <-> ST_GeometryFromText(''POINT(' 
			|| x1 || ' ' || y1 || ')'',4326) LIMIT 1' INTO rec;
	source := rec.id;
	
	EXECUTE 'SELECT id::integer FROM rede_viaria_bv_vertex
			ORDER BY geom_vertex <-> ST_GeometryFromText(''POINT(' 
			|| x2 || ' ' || y2 || ')'',4326) LIMIT 1' INTO rec;
	target := rec.id;

	-- Shortest path query (TODO: limit extent by BBOX) 
        seq := 0;
        sql := 'SELECT id, geom_way, osm_name, rede_viaria_bv.cost, source, target, 
				ST_Reverse(geom_way) AS flip_geom FROM ' ||
                        'pgr_dijkstra(''SELECT id as id, source::int, target::int, cost::double precision FROM '
                                        || quote_ident(tbl) || ''', '
                                        || source || ', ' || target 
                                        || ' , false, false), '
                                || quote_ident(tbl) || ' WHERE id2 = id ORDER BY seq';

	-- Remember start point
        point := source;

        FOR rec IN EXECUTE sql
        LOOP
		-- Flip geometry (if required)
		IF ( point != rec.source ) THEN
			rec.geom_way := rec.flip_geom;
			point := rec.source;
		ELSE
			point := rec.target;
		END IF;
        
		-- Calculate heading (simplified)
		EXECUTE 'SELECT degrees( ST_Azimuth( 
				ST_StartPoint(''' || rec.geom_way::text || '''),
				ST_EndPoint(''' || rec.geom_way::text || ''') ) )' 
			INTO heading;

		-- Return record
                seq     := seq + 1;
                gid     := rec.id;
                name    := rec.osm_name;
                cost    := rec.cost;
                geom    := rec.geom_way;
                RETURN NEXT;
        END LOOP;
        RETURN;
END;
$$;

alter function pgr_deaparab(varchar, double precision, double precision, double precision, double precision, out integer, out integer, out text, out double precision, out double precision, out geometry) owner to grupo1_ptas_2019;

